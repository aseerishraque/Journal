<?php


namespace App;


class Item extends Database
{
    public $table = "items";

    
}